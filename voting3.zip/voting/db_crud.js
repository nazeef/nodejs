var mysql      = require('mysql');
	var connection = mysql.createConnection({
	  host     : 'localhost',
	  user     : 'root',
	  password : 'root',
	  database : 'test'
	});

connection.connect();

exports.test = function(req, res){
          res.send('tested');   
};
//----------------------------------------------------------------------------
exports.vote = function(req,res){
  
    connection.query('SELECT * from votes where name ="'+ req.query.voter +'"', function(err, rows, fields) {
		if(rows.length >= 2){
			res.send("Already reached voting limit" );
			console.log('Invalid vote.');
		}
		else{
			//res.send(JSON.stringify(rows));
			console.log('valid.');
            connection.query('SELECT * from votes where contestant="'+ req.query.voteFor +'" and name ="'+ req.query.voter +'"', function(err, rows, fields) {
                if(rows.length == 0){
           
                    var data = {
                        name    : req.query.voter,
                        contestant : req.query.voteFor
                    };
                    
                    var query = connection.query("INSERT INTO votes set ? ",data, function(err, rows)
                    {
                        res.send("Thank you for voting!");
                       // res.redirect('/process_get?first_name='+ req.query.voter); 
                    });
                }
                else{
                    res.send("Already voted for this contestant. Choose another!" );
                }
                
            });
        } 
	});

};

//----------------------------------------------------------------------------

exports.process_get= function (req, res) {
    //res.send('tested'); 

   console.log(req.body);
   // Prepare output in JSON format
   response = {
       first_name:req.query.first_name,
       last_name:req.query.last_name
   };
  // res.send(JSON.stringify(response));
	var user="";
	
	connection.query('SELECT * from names where name ="'+ response.first_name +'"', function(err, rows, fields) {
		if(rows.length == 0){
			res.send("Invalid Password" );
			console.log('Invalid.');
		}
		else{
			
			console.log('valid.');
			user = rows[0].name;
			isAllowed = rows[0].isAllowed;
            isC = rows[0].isC;
            connection.query('SELECT * from names where isC = true', function(err, rows, fields) {
			  if (!err){
				console.log('The solution is: ', rows);
				res.render("list", { isC: isC,  isAllowed: isAllowed,  name: user  ,  list: rows });
                //res.send({ name: user  ,  list: rows });
			  }	
			  else
				console.log('Error while performing Query.');
			});
		}
	    
	});

	
		
};
//-----------------------------------------------------------------------------------------------------

exports.result = function (req, res) {
    //res.send('works');
    if(req.session.lastPage) {
        console.log('------------------------------------------Last page was: ' + req.session.lastPage + '. ');
    }
	connection.query('SELECT contestant, count(*) as no_of_votes from votes group by contestant order by no_of_votes desc', function(err, rows, fields) {
    //connection.query('SELECT b.name, COUNT(*) as no_of_votes FROM votes a LEFT JOIN names b ON  a.contestant = b.name AND b.isC = 1 GROUP BY b.name', function(err, rows, fields) {
		if(rows.length == 0){
			res.send("No results available" );
			console.log('Invalid.');
		}
		else{
			res.render("result", { list: rows });
            //res.send("results available" );
		}
	    
	});
};

//-------------------------------------------------------------------------------------------------------

exports.getVotedList = function (req, res) {

	connection.query('SELECT * from votes where name ="'+ req.query.name +'"', function(err, rows, fields) {
			res.send(rows);
	});
};

//-------------------------------------------------------------------------------------------------------

exports.resetVotes = function (req, res) {

	connection.query('DELETE from votes where name ="'+ req.query.voter +'"', function(err, rows, fields) {
			res.send("FULL RESET!");
	});
};

//-------------------------------------------------------------------------------------------------------

exports.admin = function (req, res) {
            connection.query('SELECT * from names where isC = true', function(err, conts, fields) {
				
                connection.query('SELECT * from names', function(err, rows, fields) {
                    connection.query('SELECT * from messages where isRead=0 order by mid desc', function(err, msgs, fields) {
                         res.render("admin", { contestants:conts , list: rows, messages: msgs });
                    });
                   
                });
			});

};

//-------------------------------------------------------------------------------------------------------------

exports.saveVoter = function (req, res) {
            voters = req.query.voters;
            states = req.query.states;
            console.log(states);
            for(var i=0; i<voters.length; i++) {
				if(states[i] == "true")
                    connection.query('update names set isAllowed=1 where name="'+voters[i]+'"');
                else
                    connection.query('update names set isAllowed=0 where name="'+voters[i]+'"');
			}
            
            res.send('hi');
};

//-----------------------------------------------------------------------------------------------------------

exports.contest = function (req, res) {
            name = req.query.name;
            connection.query('insert into messages (name,sender,message,isRead) values ("admin","'+name+'","'+name+' has registered as contestant",0)');
            connection.query('update names set isC=1 where name="'+name+'"', function(err, rows)
            {
                res.send("Thank you for registering for election!");
            });
            
};

//-----------------------------------------------------------------------------------------------------------

exports.markRead = function (req, res) {
   
    connection.query('update messages set isRead=1 where mid='+ req.query.msgId);
};

//-----------------------------------------------------------------------------------------------------------

exports.deny = function (req, res) {
   
    connection.query('update names set isC=0 where name="'+name+'"');
    res.send(name);
};


